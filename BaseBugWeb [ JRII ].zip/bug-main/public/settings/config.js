global.creator = "@painzyfvck"
global.token = "7486265372:AAHkCoqYRUmdT2SlrYFSszirHXDzIMaBj88"
global.chatid = "7995961603"
global.watermark = "© PainzyXAttaki"
